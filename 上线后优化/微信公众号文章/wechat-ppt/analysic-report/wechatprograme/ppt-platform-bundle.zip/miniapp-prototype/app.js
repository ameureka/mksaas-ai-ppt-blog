const { baseURL } = require('./config/config.js');
App({
  globalData: { token: '', baseURL },
  onLaunch() {
    const token = wx.getStorageSync('token');
    if (token) this.globalData.token = token;
    this.login();
  },
  login() {
    const that = this;
    wx.login({
      success(res){
        if(!res.code) return;
        wx.request({
          url: that.api('/auth/login'),
          method:'POST',
          data:{ code: res.code },
          success(r){
            if(r.data && r.data.token){
              that.globalData.token = r.data.token;
              wx.setStorageSync('token', r.data.token);
            }
          }
        });
      }
    });
  },
  api(path){ return `${this.globalData.baseURL}${path}`; },
  authHeader(){
    return this.globalData.token ? { Authorization: 'Bearer ' + this.globalData.token } : {};
  }
});
