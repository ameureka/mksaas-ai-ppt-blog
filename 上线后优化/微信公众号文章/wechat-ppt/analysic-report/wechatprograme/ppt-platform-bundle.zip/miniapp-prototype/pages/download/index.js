Page({
  data:{ url:'' },
  onLoad(q){ this.setData({ url: decodeURIComponent(q.url || '') }); },
  doDownload(){
    const url = this.data.url;
    if(!url){ wx.showToast({ title:'无效链接', icon:'none' }); return; }
    wx.downloadFile({
      url,
      success: (res)=> wx.openDocument({ filePath: res.tempFilePath, showMenu: true }),
      fail: ()=> wx.showToast({ title:'下载失败', icon:'none' })
    });
  },
  copy(){ wx.setClipboardData({ data: this.data.url }); }
});
