const { request } = require('../../utils/request.js');
Page({
  data:{ profile:{} },
  onShow(){ this.fetch(); },
  async fetch(){
    try{ const data = await request({ url:'/me' }); this.setData({ profile: data || {} }); }catch(e){}
  },
  openMember(){
    wx.request({
      url: getApp().api('/pay/create'),
      method:'POST',
      header: getApp().authHeader(),
      data:{ sku:'MEMBER_MONTH' },
      success: ({data})=>{
        wx.requestPayment({
          ...data,
          success: ()=>{ wx.showToast({ title:'已开通会员' }); this.fetch(); },
          fail: ()=> wx.showToast({ title:'已取消', icon:'none' })
        });
      }
    });
  }
});
