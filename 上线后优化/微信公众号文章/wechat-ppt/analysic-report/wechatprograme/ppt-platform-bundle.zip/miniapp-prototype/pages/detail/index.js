const { request } = require('../../utils/request.js');

Page({
  data:{ id:0, item:{}, unlocked:false, showUnlock:false },
  onLoad(q){
    const id = Number(q.id||0);
    this.setData({ id, showUnlock: q.unlock==='1' });
    this.fetch();
  },
  async fetch(){
    try{
      const data = await request({ url:`/asset/${this.data.id}` });
      const unlocked = !!(data.unlocked || data.member);
      this.setData({ item:data, unlocked });
    }catch(e){}
  },
  openUnlock(){ this.setData({ showUnlock:true }); },
  closeUnlock(){ this.setData({ showUnlock:false }); },
  onUnlocked(){ this.setData({ unlocked:true, showUnlock:false }); this.download(); },
  async download(){
    try{
      const data = await request({ url:'/download/link', data:{ asset_id: this.data.id } });
      const url = data.url;
      wx.downloadFile({
        url,
        success: (res)=>{
          const filePath = res.tempFilePath;
          wx.openDocument({ filePath, showMenu:true });
        },
        fail: ()=> wx.setClipboardData({ data:url, success:()=> wx.showToast({ title:'已复制下载链接', icon:'none' }) })
      });
    }catch(e){
      wx.showToast({ title:'请先解锁/开通会员', icon:'none' });
    }
  }
});
