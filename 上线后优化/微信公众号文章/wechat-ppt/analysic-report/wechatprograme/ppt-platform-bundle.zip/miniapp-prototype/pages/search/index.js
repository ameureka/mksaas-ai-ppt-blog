const { request } = require('../../utils/request.js');
Page({
  data:{ q:'', list:[], loading:false, sortIdx:0, sorts:['热门','最新'] },
  onLoad(q){ this.setData({ q: q.q||'' }); this.search(); },
  onInput(e){ this.setData({ q: e.detail.value }); },
  onSearch(){ this.search(); },
  async search(){
    this.setData({ loading: true });
    try{
      const data = await request({ url:'/catalog/list', data:{ q:this.data.q, page:1, page_size:30 }});
      const list = Array.isArray(data.items) ? data.items : (Array.isArray(data)?data:[]);
      this.setData({ list, loading:false });
    }catch(e){ this.setData({ loading:false }); }
  },
  onSort(e){ this.setData({ sortIdx: Number(e.detail.value) }); this.search(); },
  goDetail(e){ const id = e.detail.id; wx.navigateTo({ url: `/pages/detail/index?id=${id}`}); },
  openUnlock(e){ const id = e.detail.id; wx.navigateTo({ url: `/pages/detail/index?id=${id}&unlock=1`}); }
});
