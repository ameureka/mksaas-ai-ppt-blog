const { request } = require('../../utils/request.js');

Page({
  data:{ list:[], loading:true },
  onShow(){ this.fetch(); },
  async fetch(channel){
    this.setData({loading:true});
    try{
      const data = await request({ url: '/catalog/list', data: { channel: channel || 'yearend', page:1, page_size:20 }});
      const list = Array.isArray(data.items) ? data.items : (Array.isArray(data)?data:[]);
      this.setData({ list, loading:false });
    }catch(e){ this.setData({ loading:false }); }
  },
  onChannel(e){ const c = e.currentTarget.dataset.c; this.fetch(c); },
  onSearchConfirm(e){
    const q = e.detail.value || '';
    wx.navigateTo({ url: `/pages/search/index?q=${encodeURIComponent(q)}` });
  },
  goDetail(e){ const id = e.detail.id; wx.navigateTo({ url: `/pages/detail/index?id=${id}`}); },
  openUnlock(e){ const id = e.detail.id; wx.navigateTo({ url: `/pages/detail/index?id=${id}&unlock=1`}); }
});
