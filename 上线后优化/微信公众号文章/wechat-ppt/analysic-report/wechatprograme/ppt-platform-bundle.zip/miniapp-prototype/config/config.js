/** 配置：替换为你的真实域名与激励视频广告位 adUnitId */
const config = {
  baseURL: "https://api.yourdomain.com", // ← 后端域名
  adUnitId: "adunit-xxxxxxxxxxxxxxxx"    // ← 微信流量主激励视频ID
};
module.exports = config;
