const app = getApp();
function request({url, method='GET', data={}, header={}}){
  return new Promise((resolve, reject)=>{
    wx.request({
      url: app.api(url),
      method, data,
      header: Object.assign({}, app.authHeader(), header),
      success: ({data,statusCode})=>{
        if(statusCode>=200 && statusCode<300) resolve(data);
        else reject(data);
      },
      fail: reject
    })
  });
}
module.exports = { request };
