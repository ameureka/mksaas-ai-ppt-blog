# 微信小程序原型：PPT 模板下载（激励视频 + 付费免广告）

## 使用方法
1. 用微信开发者工具导入本项目目录（`/mnt/data/miniapp-prototype`），AppID 可先用测试号。
2. 打开 `config/config.js` 替换：
   - `baseURL`：你的后端域名（已实现 /auth/login /catalog/list /asset/:id /ad/start /ad/confirm /download/link /pay/create 等）
   - `adUnitId`：微信流量主激励视频广告位 ID
3. 真机调试需配置**合法域名白名单**：request 合法域名填 `baseURL` 域名；下载域名填你的 CDN/COS 域名。
4. 首次启动会自动调用 `wx.login` → `/auth/login` 获取 token 存储。
5. 首页取 `/catalog/list`，详情页取 `/asset/:id`；解锁流程：`/ad/start` → 完播 → `/ad/confirm` → `/download/link`。

## 目录
- `pages/home`：首页/专题
- `pages/search`：搜索
- `pages/detail`：详情页 + 解锁弹层
- `pages/download`：下载页（`wx.downloadFile` + `wx.openDocument`）
- `pages/library`：已解锁（占位）
- `pages/me`：我的（会员与积分）
- `components/asset-card`、`components/unlock-modal`：卡片与解锁组件
- `config/config.js`：域名与广告位配置

## 注意
- 请在微信公众平台开通**流量主**并创建**激励视频广告位**，把 adUnitId 填入配置。
- 后端签名下载链接应为短时效（建议 60–120 分钟），并做好防盗链。
