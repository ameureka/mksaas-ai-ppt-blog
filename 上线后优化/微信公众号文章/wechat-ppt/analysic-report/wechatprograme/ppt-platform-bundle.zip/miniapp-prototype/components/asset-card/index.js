Component({
  properties:{ item: Object },
  methods:{
    onTap(){ this.triggerEvent('tap', { id: this.data.item.asset_id }); },
    onUnlock(e){ e.stopPropagation(); this.triggerEvent('unlock',{ id: this.data.item.asset_id }); }
  }
});
