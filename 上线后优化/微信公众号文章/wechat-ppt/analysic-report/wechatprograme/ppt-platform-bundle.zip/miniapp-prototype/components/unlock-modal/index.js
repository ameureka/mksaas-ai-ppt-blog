const { adUnitId } = require('../../config/config.js');
const app = getApp();
let rewardedAd = null;

Component({
  properties:{ visible: Boolean, assetId: Number },
  data:{ adSessionId: '' },
  lifetimes:{
    attached(){
      if(wx.createRewardedVideoAd){
        rewardedAd = wx.createRewardedVideoAd({ adUnitId });
        rewardedAd.onClose((res)=>{
          if(res && res.isEnded){
            wx.request({
              url: app.api('/ad/confirm'),
              method:'POST',
              header: app.authHeader(),
              data: { ad_session_id: this.data.adSessionId, asset_id: this.properties.assetId },
              success: ()=>{
                wx.showToast({ title:'已解锁', icon:'success' });
                this.triggerEvent('unlocked');
              },
              fail: ()=> wx.showToast({ title:'解锁失败', icon:'none' })
            });
          } else {
            wx.showToast({ title:'观看完整才可解锁', icon:'none' });
          }
        });
      }
    }
  },
  methods:{
    close(){ this.triggerEvent('close'); },
    startAd(){
      wx.request({
        url: app.api('/ad/start'),
        method:'POST',
        header: app.authHeader(),
        success: ({data})=>{
          this.setData({ adSessionId: data.ad_session_id });
          rewardedAd.show().catch(()=> rewardedAd.load().then(()=> rewardedAd.show()));
        },
        fail: ()=> wx.showToast({ title:'广告加载失败', icon:'none' })
      });
    },
    payOnce(){
      wx.request({
        url: app.api('/pay/create'),
        method:'POST',
        header: app.authHeader(),
        data:{ sku:'ONEOFF', asset_id: this.properties.assetId },
        success: ({data})=>{
          wx.requestPayment({
            ...data,
            success: ()=>{ wx.showToast({ title:'支付成功' }); this.triggerEvent('unlocked'); },
            fail: ()=> wx.showToast({ title:'已取消', icon:'none' })
          });
        }
      });
    },
    openMember(){
      wx.request({
        url: app.api('/pay/create'),
        method:'POST',
        header: app.authHeader(),
        data:{ sku:'MEMBER_MONTH' },
        success: ({data})=>{
          wx.requestPayment({
            ...data,
            success: ()=>{ wx.showToast({ title:'已开通会员' }); this.triggerEvent('member'); },
            fail: ()=> wx.showToast({ title:'已取消', icon:'none' })
          });
        }
      });
    }
  }
});
