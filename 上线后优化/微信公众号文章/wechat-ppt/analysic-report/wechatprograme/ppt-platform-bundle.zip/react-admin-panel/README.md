# React Admin 管理台（Vite + TypeScript）

## 功能
- 登录：/admin/login（存储 adminToken）
- 素材管理：列表、编辑、创建（对接 /admin/assets 与 /asset/:id）
- 频道/标签：列表、创建、编辑（/admin/channels /admin/tags）
- 指标看板：调用 /metrics/daily 绘制 UV→解锁→下载、完播率、收入
- 搜索权重：调用 /admin/search-weights 进行 upsert

## 本地运行
```bash
npm i
# 指定后端 API 基址
echo 'VITE_API_BASE=https://api.yourdomain.com' > .env
npm run dev
```
浏览器打开 http://localhost:5173

## 注意
- 后端需实现：
  - POST /admin/login → { token }
  - GET /admin/assets (支持 q/channel_id/status/page/ps)
  - PATCH /admin/assets/:id, POST /admin/assets
  - GET /asset/:id（用于编辑页读取单条详情）
  - GET/POST/PATCH/DELETE /admin/channels 与 /admin/tags
  - POST /admin/search-weights → { ok:true }
  - GET /metrics/daily?from=YYYY-MM-DD&to=YYYY-MM-DD → 数组

- react-admin 的分页依赖 total，本示例对列表使用 `pagination={false}` 或以 `data.length` 兜底。
  如果后端补充 `X-Total-Count` 或 total 字段，可在 `dataProvider` 中返回真实 total。
