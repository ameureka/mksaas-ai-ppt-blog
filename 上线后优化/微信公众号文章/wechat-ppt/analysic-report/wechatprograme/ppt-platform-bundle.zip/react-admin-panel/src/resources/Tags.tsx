import * as React from 'react';
import { List, Datagrid, TextField, Edit, SimpleForm, TextInput, Create, SelectInput, EditButton } from 'react-admin';

export const TagList = () => (
  <List pagination={false}>
    <Datagrid rowClick="edit">
      <TextField source="tag_id" label="ID" />
      <TextField source="name" label="名称" />
      <TextField source="status" label="状态" />
      <EditButton />
    </Datagrid>
  </List>
);

export const TagEdit = () => (
  <Edit>
    <SimpleForm>
      <TextInput source="name" label="名称" />
      <SelectInput source="status" label="状态" choices={[{id:'online',name:'online'},{id:'offline',name:'offline'}]} />
    </SimpleForm>
  </Edit>
);

export const TagCreate = () => (
  <Create>
    <SimpleForm>
      <TextInput source="name" label="名称" />
    </SimpleForm>
  </Create>
);
