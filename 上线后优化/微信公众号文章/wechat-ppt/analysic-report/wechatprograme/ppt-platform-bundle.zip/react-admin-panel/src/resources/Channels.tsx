import * as React from 'react';
import { List, Datagrid, TextField, NumberField, Edit, SimpleForm, TextInput, NumberInput, Create, SelectInput, EditButton } from 'react-admin';

export const ChannelList = () => (
  <List pagination={false}>
    <Datagrid rowClick="edit">
      <NumberField source="channel_id" label="ID" />
      <TextField source="name" label="名称" />
      <NumberField source="sort_weight" label="权重" />
      <TextField source="status" label="状态" />
      <EditButton />
    </Datagrid>
  </List>
);

export const ChannelEdit = () => (
  <Edit>
    <SimpleForm>
      <TextInput source="name" label="名称" />
      <NumberInput source="sort_weight" label="权重" />
      <SelectInput source="status" label="状态" choices={[{id:'online',name:'online'},{id:'offline',name:'offline'}]} />
    </SimpleForm>
  </Edit>
);

export const ChannelCreate = () => (
  <Create>
    <SimpleForm>
      <TextInput source="name" label="名称" />
      <NumberInput source="sort_weight" label="权重" />
    </SimpleForm>
  </Create>
);
