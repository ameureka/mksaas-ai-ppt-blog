import * as React from 'react';
import { List, Datagrid, TextField, NumberField, Edit, SimpleForm, TextInput, NumberInput, Create, SelectInput, ImageField, ImageInput, Toolbar, SaveButton, useNotify, useRefresh, useRedirect, TopToolbar, CreateButton, ExportButton, EditButton, ShowButton } from 'react-admin';

const AssetFilters = [
  <TextInput key="q" label="搜索标题" source="q" alwaysOn />,
  <TextInput key="channel" label="频道ID" source="channel" />,
  <SelectInput key="status" source="status" label="状态" choices={[
    { id: 'online', name: 'online' },
    { id: 'offline', name: 'offline' },
  ]} />
];

export const AssetList = () => (
  <List filters={AssetFilters} pagination={false} sort={{ field: 'updated_at', order: 'DESC' }}>
    <Datagrid rowClick="edit">
      <TextField source="asset_id" label="ID" />
      <TextField source="title" label="标题" />
      <TextField source="scene" label="场景" />
      <NumberField source="pages" label="页数" />
      <NumberField source="size_bytes" label="大小(B)" />
      <TextField source="status" label="状态" />
      <EditButton />
    </Datagrid>
  </List>
);

const AssetToolbar = (props:any) => (
  <Toolbar {...props}>
    <SaveButton />
  </Toolbar>
);

export const AssetEdit = () => (
  <Edit mutationMode="pessimistic">
    <SimpleForm toolbar={<AssetToolbar />}>
      <TextInput source="asset_id" label="ID" disabled />
      <TextInput source="title" label="标题" />
      <TextInput source="cover" label="封面URL" fullWidth />
      <TextInput source="file_key" label="COS Key" fullWidth />
      <NumberInput source="pages" label="页数" />
      <NumberInput source="size_bytes" label="大小(B)" />
      <TextInput source="scene" label="场景" />
      <SelectInput source="status" label="状态" choices={[{ id:'online', name:'online'},{id:'offline', name:'offline'}]} />
      <NumberInput source="channel_id" label="频道ID" />
      <TextInput source="labels" label="标签(JSON)" helperText="如：[&quot;年终&quot;,&quot;答辩&quot;]" fullWidth />
    </SimpleForm>
  </Edit>
);

export const AssetCreate = () => (
  <Create>
    <SimpleForm>
      <TextInput source="title" label="标题" required />
      <TextInput source="cover" label="封面URL" required fullWidth />
      <TextInput source="file_key" label="COS Key" required fullWidth />
      <NumberInput source="pages" label="页数" />
      <NumberInput source="size_bytes" label="大小(B)" />
      <TextInput source="scene" label="场景" />
      <NumberInput source="channel_id" label="频道ID" />
      <TextInput source="tags" label="标签（逗号分隔）" helperText="系统会自动创建标签并关联" />
    </SimpleForm>
  </Create>
);
