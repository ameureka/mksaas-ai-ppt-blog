import * as React from 'react';
import { Card, CardContent, CardHeader } from '@mui/material';
import { Title } from 'react-admin';
import { LineChart, Line, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, CartesianGrid, BarChart, Bar } from 'recharts';

const API = import.meta.env.VITE_API_BASE || 'https://api.yourdomain.com';

function useAdminFetch(url: string) {
  const [data, setData] = React.useState<any[]>([]);
  const [loading, setLoading] = React.useState(false);
  React.useEffect(() => {
    const token = localStorage.getItem('adminToken');
    setLoading(true);
    fetch(url, { headers: { Authorization: token ? 'Bearer ' + token : '' } })
      .then(r => r.json()).then(setData).finally(() => setLoading(false));
  }, [url]);
  return { data, loading };
}

export default function MetricsPage() {
  const [from, setFrom] = React.useState<string>(() => {
    const d = new Date(Date.now() - 7*24*3600*1000);
    return d.toISOString().slice(0,10);
  });
  const [to, setTo] = React.useState<string>(() => new Date().toISOString().slice(0,10));
  const { data } = useAdminFetch(`${API}/metrics/daily?from=${from}&to=${to}`);

  return (
    <>
      <Title title="指标看板" />
      <Card sx={{mb:2}}>
        <CardHeader title="时间范围" />
        <CardContent>
          <input type="date" value={from} onChange={e=>setFrom(e.target.value)} />
          <span style={{margin:'0 8px'}}>—</span>
          <input type="date" value={to} onChange={e=>setTo(e.target.value)} />
        </CardContent>
      </Card>

      <Card sx={{mb:2}}>
        <CardHeader title="UV → 解锁 → 下载（条形图）" />
        <CardContent style={{ height: 300 }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="day" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="uv" name="UV" />
              <Bar dataKey="unlocks" name="解锁" />
              <Bar dataKey="downloads" name="下载" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card sx={{mb:2}}>
        <CardHeader title="广告完播率 & 会员转化（折线）" />
        <CardContent style={{ height: 300 }}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="day" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="ad_finish_rate" name="广告完播率(%)" dot={false} />
              <Line type="monotone" dataKey="members_paid" name="会员付款人数" dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card sx={{mb:2}}>
        <CardHeader title="收入（分）" />
        <CardContent style={{ height: 280 }}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="day" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="revenue_cent" name="总收入(分)" dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </>
  );
}
