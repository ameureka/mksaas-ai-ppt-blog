import { DataProvider } from 'react-admin';

const API = import.meta.env.VITE_API_BASE || 'https://api.yourdomain.com';

function authHeader() {
  const token = localStorage.getItem('adminToken');
  return token ? { Authorization: 'Bearer ' + token } : {};
}

async function http(url: string, options: RequestInit = {}) {
  const res = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {}),
      ...authHeader()
    }
  });
  const text = await res.text();
  let json: any = null;
  try { json = text ? JSON.parse(text) : null; } catch { json = text; }
  if (!res.ok) {
    const err: any = new Error(json?.error || res.statusText);
    err.status = res.status;
    throw err;
  }
  return { json, headers: res.headers };
}

export const dataProvider: DataProvider = {
  // Assets
  getList: async (resource, params) => {
    if (resource === 'assets') {
      const { page, perPage } = params.pagination;
      const { field, order } = params.sort;
      const q = (params.filter?.q as string) || '';
      const channel = (params.filter?.channel as string) || '';
      const status = (params.filter?.status as string) || '';
      const url = new URL(API + '/admin/assets');
      if (q) url.searchParams.set('q', q);
      if (channel) url.searchParams.set('channel_id', channel);
      if (status) url.searchParams.set('status', status);
      url.searchParams.set('page', String(page));
      url.searchParams.set('ps', String(perPage));
      const { json } = await http(url.toString());
      const data = Array.isArray(json) ? json : (json.items || []);
      // react-admin 需要 total，这里返回当前页数量，若后端未提供总数
      return { data, total: data.length };
    }
    if (resource === 'channels') {
      const url = new URL(API + '/admin/channels');
      const { json } = await http(url.toString());
      return { data: Array.isArray(json) ? json : (json.items || []), total: (json.items || json || []).length };
    }
    if (resource === 'tags') {
      const url = new URL(API + '/admin/tags');
      const { json } = await http(url.toString());
      return { data: Array.isArray(json) ? json : (json.items || []), total: (json.items || json || []).length };
    }
    throw new Error('Unsupported resource: ' + resource);
  },
  getOne: async (resource, params) => {
    if (resource === 'assets') {
      const { json } = await http(`${API}/asset/${params.id}`); // 复用前台详情
      return { data: json };
    }
    if (resource === 'channels') {
      const { json } = await http(`${API}/admin/channels?id=${params.id}`);
      return { data: Array.isArray(json) ? json[0] : json };
    }
    if (resource === 'tags') {
      const { json } = await http(`${API}/admin/tags?id=${params.id}`);
      return { data: Array.isArray(json) ? json[0] : json };
    }
    throw new Error('Unsupported resource');
  },
  create: async (resource, params) => {
    if (resource === 'assets') {
      const { json } = await http(`${API}/admin/assets`, { method: 'POST', body: JSON.stringify(params.data) });
      return { data: { id: json.id, ...params.data } };
    }
    if (resource === 'channels') {
      const { json } = await http(`${API}/admin/channels`, { method: 'POST', body: JSON.stringify(params.data) });
      return { data: { id: json.channel_id || json.id, ...params.data } };
    }
    if (resource === 'tags') {
      const { json } = await http(`${API}/admin/tags`, { method: 'POST', body: JSON.stringify(params.data) });
      return { data: { id: json.tag_id || json.id, ...params.data } };
    }
    throw new Error('Unsupported resource');
  },
  update: async (resource, params) => {
    if (resource === 'assets') {
      await http(`${API}/admin/assets/${params.id}`, { method: 'PATCH', body: JSON.stringify(params.data) });
      return { data: params.data };
    }
    if (resource === 'channels') {
      await http(`${API}/admin/channels/${params.id}`, { method: 'PATCH', body: JSON.stringify(params.data) });
      return { data: params.data };
    }
    if (resource === 'tags') {
      await http(`${API}/admin/tags/${params.id}`, { method: 'PATCH', body: JSON.stringify(params.data) });
      return { data: params.data };
    }
    throw new Error('Unsupported resource');
  },
  delete: async (resource, params) => {
    await http(`${API}/admin/${resource}/${params.id}`, { method: 'DELETE' });
    return { data: params.previousData };
  },
  // not used
  getMany: async () => ({ data: [] } as any),
  getManyReference: async () => ({ data: [], total: 0 } as any),
  updateMany: async () => ({ data: [] } as any),
  deleteMany: async () => ({ data: [] } as any),
};
