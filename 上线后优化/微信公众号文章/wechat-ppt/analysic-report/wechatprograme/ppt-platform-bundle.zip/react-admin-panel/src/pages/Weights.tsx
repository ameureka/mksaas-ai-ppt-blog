import * as React from 'react';
import { Card, CardContent, CardHeader, Button, TextField, MenuItem } from '@mui/material';
import { Title, useNotify } from 'react-admin';

const API = import.meta.env.VITE_API_BASE || 'https://api.yourdomain.com';

export default function WeightsPage() {
  const [scope, setScope] = React.useState<'channel' | 'tag'>('channel');
  const [refId, setRefId] = React.useState<string>('');
  const [weight, setWeight] = React.useState<number>(0);
  const notify = useNotify();

  const submit = async () => {
    try {
      const token = localStorage.getItem('adminToken');
      const res = await fetch(`${API}/admin/search-weights`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: token ? 'Bearer ' + token : '' },
        body: JSON.stringify({ scope, ref_id: Number(refId), weight: Number(weight) })
      });
      if (!res.ok) throw new Error(await res.text());
      notify('已更新权重', { type: 'success' });
    } catch (e:any) {
      notify('更新失败：' + (e.message || 'error'), { type: 'warning' });
    }
  };

  return (
    <>
      <Title title="搜索权重调整" />
      <Card>
        <CardHeader title="按频道/标签调整搜索权重" />
        <CardContent>
          <TextField
            select label="Scope" value={scope}
            onChange={(e)=> setScope(e.target.value as any)}
            sx={{mr:2, minWidth:160}}
          >
            <MenuItem value="channel">channel</MenuItem>
            <MenuItem value="tag">tag</MenuItem>
          </TextField>
          <TextField label="ref_id" value={refId} onChange={e=>setRefId(e.target.value)} sx={{mr:2}} />
          <TextField label="weight(-100~100)" type="number" value={weight} onChange={e=>setWeight(Number(e.target.value))} sx={{mr:2}} />
          <Button variant="contained" onClick={submit}>提交</Button>
        </CardContent>
      </Card>
    </>
  );
}
