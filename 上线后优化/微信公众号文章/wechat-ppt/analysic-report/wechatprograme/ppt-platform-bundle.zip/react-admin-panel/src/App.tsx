import * as React from 'react';
import { Admin, Resource, ListGuesser, Layout, AppBar, TitlePortal } from 'react-admin';
import { dataProvider } from './dataProvider';
import { authProvider } from './authProvider';
import { AssetList, AssetEdit, AssetCreate } from './resources/Assets';
import { ChannelList, ChannelEdit, ChannelCreate } from './resources/Channels';
import { TagList, TagEdit, TagCreate } from './resources/Tags';
import MetricsPage from './pages/Metrics';
import WeightsPage from './pages/Weights';
import { createTheme } from '@mui/material/styles';
import { Typography } from '@mui/material';

const theme = createTheme({
  palette: {
    primary: { main: '#4C6FFF' },
    secondary: { main: '#7C4DFF' }
  }
});

const CustomAppBar = () => (
  <AppBar>
    <TitlePortal />
    <Typography variant="h6" sx={{ flex: 1, textAlign: 'right', pr: 2 }}>PPT 管理后台</Typography>
  </AppBar>
);

const CustomLayout = (props:any) => <Layout {...props} appBar={CustomAppBar} />;

const Dashboard = () => <MetricsPage />;

export default function App(){
  return (
    <Admin
      title="PPT Admin"
      theme={theme}
      dataProvider={dataProvider}
      authProvider={authProvider}
      layout={CustomLayout}
      dashboard={Dashboard}
      loginPage={undefined}
    >
      <Resource name="assets" options={{label:'素材/模板'}}
        list={AssetList} edit={AssetEdit} create={AssetCreate} />
      <Resource name="channels" options={{label:'频道'}}
        list={ChannelList} edit={ChannelEdit} create={ChannelCreate} />
      <Resource name="tags" options={{label:'标签'}}
        list={TagList} edit={TagEdit} create={TagCreate} />
      {/* 自定义页面：指标看板、搜索权重 */}
      {/* 使用 fake resources 显示菜单项 */}
      <Resource name="metrics" options={{label:'指标看板'}} list={MetricsPage as any} />
      <Resource name="weights" options={{label:'搜索权重'}} list={WeightsPage as any} />
    </Admin>
  );
}
