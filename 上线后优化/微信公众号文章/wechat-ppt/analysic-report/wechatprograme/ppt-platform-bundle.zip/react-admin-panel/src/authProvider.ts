import type { AuthProvider } from 'react-admin';

export const authProvider: AuthProvider = {
  login: async ({ username, password }) => {
    const res = await fetch(`${import.meta.env.VITE_API_BASE || 'https://api.yourdomain.com'}/admin/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    if (!res.ok) throw new Error('登录失败');
    const data = await res.json();
    localStorage.setItem('adminToken', data.token);
    return Promise.resolve();
  },
  logout: () => {
    localStorage.removeItem('adminToken');
    return Promise.resolve();
  },
  checkAuth: () => {
    return localStorage.getItem('adminToken') ? Promise.resolve() : Promise.reject();
  },
  checkError: (error) => {
    const status = (error as any)?.status;
    if (status === 401 || status === 403) {
      localStorage.removeItem('adminToken');
      return Promise.reject();
    }
    return Promise.resolve();
  },
  getPermissions: () => Promise.resolve('admin'),
  getIdentity: async () => ({ id: 'admin', fullName: 'Administrator' } as any),
};
