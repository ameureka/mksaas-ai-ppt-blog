CREATE DATABASE IF NOT EXISTS pptdb DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE pptdb;

-- 用户
CREATE TABLE IF NOT EXISTS users (
  uid BIGINT PRIMARY KEY AUTO_INCREMENT,
  openid VARCHAR(64) UNIQUE,
  nickname VARCHAR(64),
  credits INT NOT NULL DEFAULT 0,
  membership_type ENUM('none','monthly') NOT NULL DEFAULT 'none',
  membership_expire_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 资源
CREATE TABLE IF NOT EXISTS assets (
  asset_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(200) NOT NULL,
  cover VARCHAR(500),
  file_key VARCHAR(500) NOT NULL,
  pages INT DEFAULT 0,
  size_bytes BIGINT DEFAULT 0,
  scene VARCHAR(64),
  labels JSON,
  channel_id INT NULL,
  status ENUM('online','offline') NOT NULL DEFAULT 'online',
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_assets_list (status, channel_id, updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 解锁
CREATE TABLE IF NOT EXISTS unlocks (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  uid BIGINT NOT NULL,
  asset_id BIGINT NOT NULL,
  method ENUM('ad','pay','credit') NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at DATETIME NULL,
  UNIQUE KEY uq_user_asset (uid, asset_id),
  INDEX idx_unlocks_user_time (uid, created_at),
  CONSTRAINT fk_un_user FOREIGN KEY (uid) REFERENCES users(uid),
  CONSTRAINT fk_un_asset FOREIGN KEY (asset_id) REFERENCES assets(asset_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 下载
CREATE TABLE IF NOT EXISTS downloads (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  uid BIGINT NOT NULL,
  asset_id BIGINT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_dl (uid, asset_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 订单
CREATE TABLE IF NOT EXISTS orders (
  order_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  uid BIGINT NOT NULL,
  type ENUM('oneoff','member') NOT NULL,
  amount_cent INT NOT NULL,
  sku VARCHAR(32) NOT NULL,
  status ENUM('pending','paid','closed') NOT NULL DEFAULT 'pending',
  pay_txn_id VARCHAR(64) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_order_uid (uid, updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 商品
CREATE TABLE IF NOT EXISTS products (
  sku VARCHAR(32) PRIMARY KEY,
  name VARCHAR(64) NOT NULL,
  type ENUM('oneoff','member') NOT NULL,
  price_cent INT NOT NULL,
  meta JSON,
  status ENUM('online','offline') NOT NULL DEFAULT 'online',
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO products(sku,name,type,price_cent,meta) VALUES
('ONEOFF','单次下载','oneoff',100,'{}'),
('MEMBER_MONTH','月会员','member',990,'{"durationDays":30}');

-- 支付日志
CREATE TABLE IF NOT EXISTS pay_logs (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  order_id BIGINT NOT NULL,
  raw_json JSON,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 激励广告会话
CREATE TABLE IF NOT EXISTS ad_sessions (
  ad_session_id VARCHAR(64) PRIMARY KEY,
  uid BIGINT NOT NULL,
  asset_id BIGINT NULL,
  status ENUM('issued','rewarded','expired') NOT NULL DEFAULT 'issued',
  issued_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  rewarded_at DATETIME NULL,
  INDEX idx_ad_uid (uid, issued_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 邮件队列与事件
CREATE TABLE IF NOT EXISTS email_queue (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  uid BIGINT NOT NULL,
  asset_id BIGINT NOT NULL,
  email VARCHAR(200) NOT NULL,
  status ENUM('queued','sent','fail') NOT NULL DEFAULT 'queued',
  retries INT NOT NULL DEFAULT 0,
  last_error VARCHAR(255) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS mail_events (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  email_id BIGINT NOT NULL,
  event ENUM('bounced','delivered','opened') NOT NULL,
  detail JSON,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_email (email_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 频道/标签/权重
CREATE TABLE IF NOT EXISTS channels (
  channel_id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(32) UNIQUE NOT NULL,
  status ENUM('online','offline') NOT NULL DEFAULT 'online',
  sort_weight INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS tags (
  tag_id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(32) UNIQUE NOT NULL,
  status ENUM('online','offline') NOT NULL DEFAULT 'online'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS asset_tags (
  asset_id BIGINT NOT NULL,
  tag_id INT NOT NULL,
  PRIMARY KEY(asset_id, tag_id),
  CONSTRAINT fk_at_asset FOREIGN KEY (asset_id) REFERENCES assets(asset_id),
  CONSTRAINT fk_at_tag FOREIGN KEY (tag_id) REFERENCES tags(tag_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS search_weights (
  id INT PRIMARY KEY AUTO_INCREMENT,
  scope ENUM('channel','tag') NOT NULL,
  ref_id INT NOT NULL,
  weight INT NOT NULL DEFAULT 0,
  UNIQUE KEY uq_scope_ref (scope, ref_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 指标（日）
CREATE TABLE IF NOT EXISTS metrics_daily (
  day DATE PRIMARY KEY,
  uv INT NOT NULL DEFAULT 0,
  unlocks INT NOT NULL DEFAULT 0,
  downloads INT NOT NULL DEFAULT 0,
  ad_issued INT NOT NULL DEFAULT 0,
  ad_rewarded INT NOT NULL DEFAULT 0,
  members_paid INT NOT NULL DEFAULT 0,
  revenue_cent INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
