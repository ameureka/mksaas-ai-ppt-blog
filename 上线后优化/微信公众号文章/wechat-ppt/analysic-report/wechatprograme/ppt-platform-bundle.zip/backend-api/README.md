# PPT Backend API (Node 18 + Express + MySQL)

- 登录：/auth/login（小程序 wx.login code → 颁发用户 JWT；当前示例为简化 stub）
- 资源：/catalog/list、/asset/:id
- 解锁：/ad/start、/ad/confirm、/download/link
- 支付：/pay/create（ONEOFF / MEMBER_MONTH）、/pay/notify（微信 v3 强验签）
- 邮件：/email/send + 消费器 workers/email-consumer.ts
- CMS：/admin/login、/admin/assets、/admin/channels、/admin/tags、/admin/search-weights
- 指标：/metrics/daily（配合 workers/metrics-daily.ts）

## 本地启动
```bash
cp .env.example .env
# 修改数据库与域名等配置
npm i
npm run dev
```

## 初始化数据库
执行 `schema.sql`。
