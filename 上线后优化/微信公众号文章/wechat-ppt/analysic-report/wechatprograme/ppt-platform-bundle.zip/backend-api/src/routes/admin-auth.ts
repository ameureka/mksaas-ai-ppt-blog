import { Router } from 'express';
import jwt from 'jsonwebtoken';

const r = Router();

r.post('/admin/login', (req, res) => {
  const { username, password } = req.body || {};
  if (username === process.env.ADMIN_USER && password === process.env.ADMIN_PASS) {
    const token = jwt.sign({ role: 'admin', u: username }, process.env.ADMIN_JWT_SECRET || 'admin_secret', { expiresIn: '7d' });
    return res.json({ token, role: 'admin' });
  }
  return res.status(401).json({ error: 'BAD_CREDENTIALS' });
});

export default r;
