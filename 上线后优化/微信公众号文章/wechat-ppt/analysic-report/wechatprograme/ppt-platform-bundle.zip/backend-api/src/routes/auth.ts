import { Router } from 'express';
import jwt from 'jsonwebtoken';
import { pool } from '../utils/db';

const r = Router();

/** 简化的登录：使用 code 作为伪 openid，生产请替换为微信 code2Session */
r.post('/auth/login', async (req, res, next) => {
  try {
    const { code } = req.body || {};
    const openid = 'test_' + (code || Math.random().toString(36).slice(2));
    let uid = 0;
    const [rows]: any = await pool.query(`SELECT uid FROM users WHERE openid=?`, [openid]);
    if (rows.length) {
      uid = rows[0].uid;
    } else {
      const [ins]: any = await pool.query(`INSERT INTO users(openid, nickname) VALUES(?, ?)`, [openid, '游客']);
      uid = ins.insertId;
    }
    const token = jwt.sign({ uid, openid }, process.env.USER_JWT_SECRET || 'user_secret', { expiresIn: '30d' });
    res.json({ token, uid });
  } catch (e) { next(e); }
});

export default r;
