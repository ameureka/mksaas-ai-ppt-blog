import 'dotenv/config';
import { pool } from '../utils/db';
import nodemailer from 'nodemailer';

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST!,
  port: Number(process.env.SMTP_PORT || 465),
  secure: true,
  auth: { user: process.env.SMTP_USER!, pass: process.env.SMTP_PASS! }
});

async function pickBatch(limit=50) {
  const [rows]: any = await pool.query(
    `SELECT * FROM email_queue WHERE status='queued' ORDER BY id ASC LIMIT ?`, [limit]
  );
  return rows;
}

async function sendOne(item: any) {
  try {
    const [a]: any = await pool.query(`SELECT title, file_key FROM assets WHERE asset_id=?`, [item.asset_id]);
    const subject = `【下载链接】${a[0]?.title ?? 'PPT模板'}（90分钟有效）`;
    const base = (process.env.CDN_HOST || 'https://cdn.example.com').replace(/\/$/,'');
    const url = `${base}/${encodeURIComponent(a[0]?.file_key || '')}`;
    const html = `<p>您好，点击以下链接下载（90分钟有效）：</p><p><a href="${url}">${url}</a></p>`;
    await transporter.sendMail({ from: process.env.SMTP_USER!, to: item.email, subject, html });
    await pool.query(`UPDATE email_queue SET status='sent' WHERE id=?`, [item.id]);
  } catch (e: any) {
    const retry = (item.retries || 0) + 1;
    const status = retry >= 5 ? 'fail' : 'queued';
    await pool.query(
      `UPDATE email_queue SET status=?, retries=?, last_error=? WHERE id=?`,
      [status, retry, String(e.message).slice(0,240), item.id]
    );
  }
}

async function loop() {
  const batch = await pickBatch(50);
  if (batch.length === 0) return;
  await Promise.all(batch.map(sendOne));
}

(async function main() {
  setInterval(loop, 3000);
})();
