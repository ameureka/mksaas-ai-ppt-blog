import { Router } from 'express';
import { auth } from '../middleware/auth';
import { pool } from '../utils/db';

const r = Router();

r.get('/download/link', auth, async (req, res, next) => {
  try {
    const uid = (req as any).user.uid;
    const asset_id = Number((req.query.asset_id as string) || 0);
    if (!asset_id) return res.status(400).json({ error: 'MISSING_ASSET_ID' });

    const [[unlocked]]: any = await pool.query(
      `SELECT 1 AS ok FROM unlocks WHERE uid=? AND asset_id=? AND (expires_at IS NULL OR expires_at>NOW()) LIMIT 1`,
      [uid, asset_id]
    );
    const [[member]]: any = await pool.query(
      `SELECT CASE WHEN membership_expire_at IS NOT NULL AND membership_expire_at>NOW() THEN 1 ELSE 0 END AS m
         FROM users WHERE uid=? LIMIT 1`, [uid]);

    if (!unlocked?.ok && member?.m !== 1) return res.status(403).json({ error: 'NO_ENTITLEMENT' });

    const [[a]]: any = await pool.query(`SELECT file_key FROM assets WHERE asset_id=?`, [asset_id]);
    if (!a) return res.status(404).json({ error: 'ASSET_NOT_FOUND' });

    const base = process.env.CDN_HOST || 'https://cdn.example.com';
    const url = `${base.replace(/\/$/,'')}/${encodeURIComponent(a.file_key)}`; // TODO: 改为真实签名 URL
    await pool.query(`INSERT INTO downloads(uid, asset_id) VALUES(?, ?)`, [uid, asset_id]);
    await pool.query(
      `INSERT INTO metrics_daily(day, downloads) VALUES(CURDATE(),1)
         ON DUPLICATE KEY UPDATE downloads=downloads+1`);
    res.json({ url, ttl_sec: 3600 });
  } catch (e) { next(e); }
});

export default r;
