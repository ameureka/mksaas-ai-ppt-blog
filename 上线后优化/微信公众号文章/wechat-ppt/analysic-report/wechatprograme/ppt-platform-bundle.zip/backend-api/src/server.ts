import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
dotenv.config();

import authRoute from './routes/auth';
import adminAuthRoute from './routes/admin-auth';
import catalogRoute from './routes/catalog';
import meRoute from './routes/me';
import emailRoute from './routes/email';
import adminRoute from './routes/admin';
import adRoute from './routes/ad';
import downloadRoute from './routes/download';
import payRoute from './routes/pay';
import mailRoute from './routes/mail';
import metricsRoute from './routes/metrics';

const app = express();
app.use(cors());
app.use(express.json({ limit: '2mb' }));

app.get('/health', (_req, res) => res.json({ ok: true }));

app.use(authRoute);
app.use(adminAuthRoute);
app.use(catalogRoute);
app.use(meRoute);
app.use(emailRoute);
app.use(adminRoute);
app.use(adRoute);
app.use(downloadRoute);
app.use(payRoute);
app.use(mailRoute);
app.use(metricsRoute);

// error handler
app.use((err: any, _req: any, res: any, _next: any) => {
  console.error(err);
  res.status(500).json({ error: err.message || 'SERVER_ERROR' });
});

const port = Number(process.env.PORT || 8080);
app.listen(port, () => console.log('API listening on ' + port));
