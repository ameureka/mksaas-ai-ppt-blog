import { Router } from 'express';
import { auth } from '../middleware/auth';
import { pool } from '../utils/db';

const r = Router();
function isEmail(s: string) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s); }

r.post('/email/send', auth, async (req, res, next) => {
  try {
    const uid = (req as any).user.uid;
    const { asset_id, email } = req.body || {};
    if (!asset_id) return res.status(400).json({ error: 'MISSING_ASSET_ID' });
    if (!email || !isEmail(email)) return res.status(400).json({ error: 'INVALID_EMAIL' });

    const [[unlocked]]: any = await pool.query(
      `SELECT 1 AS ok FROM unlocks WHERE uid=? AND asset_id=? AND (expires_at IS NULL OR expires_at>NOW()) LIMIT 1`,
      [uid, Number(asset_id)]
    );
    const [[member]]: any = await pool.query(
      `SELECT CASE WHEN membership_expire_at IS NOT NULL AND membership_expire_at>NOW() THEN 1 ELSE 0 END AS m
         FROM users WHERE uid=? LIMIT 1`, [uid]);

    if (!unlocked?.ok && member?.m !== 1) return res.status(403).json({ error: 'NO_ENTITLEMENT' });

    await pool.query(
      `INSERT INTO email_queue(uid, asset_id, email, status) VALUES(?, ?, ?, 'queued')`,
      [uid, Number(asset_id), String(email)]
    );
    res.json({ ok: true });
  } catch (e) { next(e); }
});

export default r;
