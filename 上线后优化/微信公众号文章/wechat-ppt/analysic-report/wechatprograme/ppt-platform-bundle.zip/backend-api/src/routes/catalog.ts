import { Router } from 'express';
import { pool } from '../utils/db';
import { auth } from '../middleware/auth';

const r = Router();

r.get('/catalog/list', async (req, res, next) => {
  try {
    const { channel = '', tag = '', q = '', page = '1', page_size = '20' } = req.query as any;
    const ps = Math.min(Math.max(parseInt(page_size as string, 10) || 20, 1), 50);
    const off = (parseInt(page as string, 10) - 1) * ps;

    const where: string[] = ["a.status='online'"];
    const params: any[] = [];
    if (channel) { where.push('a.channel_id = (SELECT channel_id FROM channels WHERE name=? LIMIT 1)'); params.push(channel); }
    if (tag)     { where.push('EXISTS (SELECT 1 FROM asset_tags at JOIN tags t ON at.tag_id=t.tag_id WHERE at.asset_id=a.asset_id AND t.name=?)'); params.push(tag); }
    if (q)       { where.push('(a.title LIKE CONCAT("%",?,"%"))'); params.push(q); }

    const sql = `
      SELECT a.asset_id, a.title, a.cover, a.pages, a.size_bytes, a.scene, a.labels
        FROM assets a
       WHERE ${where.join(' AND ')}
       ORDER BY a.updated_at DESC
       LIMIT ?,?`;
    params.push(off, ps);

    const [items] = await pool.query(sql, params);
    res.json({ items });
  } catch (e) { next(e); }
});

r.get('/asset/:id', auth, async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const uid = (req as any).user.uid;
    const [rows]: any = await pool.query(
      `SELECT asset_id, title, cover, pages, size_bytes, labels, scene, file_key, status
         FROM assets WHERE asset_id=? AND status='online' LIMIT 1`, [id]);
    if (!rows.length) return res.status(404).json({ error: 'ASSET_NOT_FOUND' });
    const asset = rows[0];

    const [[unlock]]: any = await pool.query(
      `SELECT 1 AS ok FROM unlocks 
        WHERE uid=? AND asset_id=? 
          AND (expires_at IS NULL OR expires_at > NOW())
        LIMIT 1`, [uid, id]);

    const [[member]]: any = await pool.query(
      `SELECT CASE WHEN membership_expire_at IS NOT NULL AND membership_expire_at>NOW() THEN 1 ELSE 0 END AS m
         FROM users WHERE uid=? LIMIT 1`, [uid]);

    res.json({ ...asset, unlocked: !!(unlock && unlock.ok), member: member?.m === 1 });
  } catch (e) { next(e); }
});

export default r;
