import { Router } from 'express';
import { auth } from '../middleware/auth';
import { pool } from '../utils/db';
import { v4 as uuidv4 } from 'uuid';

const r = Router();

r.post('/ad/start', auth, async (req, res, next) => {
  try {
    const uid = (req as any).user.uid;
    const ad_session_id = uuidv4().replace(/-/g,'');
    await pool.query(`INSERT INTO ad_sessions(ad_session_id, uid, status) VALUES(?,?, 'issued')`, [ad_session_id, uid]);
    await pool.query(
      `INSERT INTO metrics_daily(day, ad_issued)
         VALUES(CURDATE(), 1)
       ON DUPLICATE KEY UPDATE ad_issued = ad_issued + 1`);
    res.json({ ad_session_id });
  } catch (e) { next(e); }
});

r.post('/ad/confirm', auth, async (req, res, next) => {
  try {
    const uid = (req as any).user.uid;
    const { ad_session_id, asset_id } = req.body || {};
    if (!ad_session_id || !asset_id) return res.status(400).json({ error: 'MISSING_PARAM' });
    const [rows]: any = await pool.query(`SELECT status FROM ad_sessions WHERE ad_session_id=? AND uid=?`, [ad_session_id, uid]);
    if (!rows.length) return res.status(404).json({ error: 'SESSION_NOT_FOUND' });
    if (rows[0].status === 'rewarded') return res.json({ ok: true });

    await pool.query(`UPDATE ad_sessions SET status='rewarded', rewarded_at=NOW(), asset_id=? WHERE ad_session_id=?`, [asset_id, ad_session_id]);
    await pool.query(
      `INSERT INTO unlocks(uid, asset_id, method, expires_at)
         VALUES(?, ?, 'ad', DATE_ADD(NOW(), INTERVAL 1 DAY))
       ON DUPLICATE KEY UPDATE expires_at=GREATEST(expires_at, DATE_ADD(NOW(), INTERVAL 1 DAY))`,
      [uid, Number(asset_id)]
    );
    await pool.query(
      `INSERT INTO metrics_daily(day, ad_rewarded, unlocks)
         VALUES(CURDATE(), 1, 1)
       ON DUPLICATE KEY UPDATE ad_rewarded = ad_rewarded + 1, unlocks = unlocks + 1`);
    res.json({ ok: true });
  } catch (e) { next(e); }
});

export default r;
