import jwt from 'jsonwebtoken';
import { Request, Response, NextFunction } from 'express';

export function adminAuth(req: Request & { admin?: any }, res: Response, next: NextFunction) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : '';
  try {
    const payload: any = jwt.verify(token, process.env.ADMIN_JWT_SECRET || 'admin_secret');
    if (!payload || payload.role !== 'admin') throw new Error('NO_ADMIN');
    (req as any).admin = payload;
    next();
  } catch {
    res.status(401).json({ error: 'UNAUTHORIZED' });
  }
}
