import { Router } from 'express';
import { pool } from '../utils/db';

const r = Router();

r.post('/mail/bounce', async (req, res) => {
  const { email_id, event, detail } = req.body || {};
  await pool.query(`INSERT INTO mail_events(email_id, event, detail) VALUES(?,?,?)`, [email_id, event, JSON.stringify(detail||{})]);
  if (event === 'bounced') {
    await pool.query(`UPDATE email_queue SET status='fail', last_error='bounced' WHERE id=?`, [email_id]);
  }
  res.json({ ok:true });
});

export default r;
