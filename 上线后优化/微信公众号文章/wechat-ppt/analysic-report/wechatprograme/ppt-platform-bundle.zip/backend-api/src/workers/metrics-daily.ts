import { pool } from '../utils/db';

async function run() {
  await pool.query(`
    INSERT INTO metrics_daily(day, uv, unlocks, downloads, ad_issued, ad_rewarded, members_paid, revenue_cent)
    SELECT
      CURDATE() - INTERVAL 1 DAY AS day,
      COALESCE((SELECT uv FROM access_logs WHERE day=CURDATE()-INTERVAL 1 DAY),0) AS uv,
      (SELECT COUNT(*) FROM unlocks WHERE DATE(created_at)=CURDATE()-INTERVAL 1 DAY) AS unlocks,
      (SELECT COUNT(*) FROM downloads WHERE DATE(created_at)=CURDATE()-INTERVAL 1 DAY) AS downloads,
      (SELECT COUNT(*) FROM ad_sessions WHERE DATE(issued_at)=CURDATE()-INTERVAL 1 DAY) AS ad_issued,
      (SELECT COUNT(*) FROM ad_sessions WHERE DATE(rewarded_at)=CURDATE()-INTERVAL 1 DAY AND status='rewarded') AS ad_rewarded,
      (SELECT COUNT(*) FROM orders WHERE DATE(updated_at)=CURDATE()-INTERVAL 1 DAY AND type='member' AND status='paid') AS members_paid,
      (SELECT COALESCE(SUM(amount_cent),0) FROM orders WHERE DATE(updated_at)=CURDATE()-INTERVAL 1 DAY AND status='paid') AS revenue_cent
    ON DUPLICATE KEY UPDATE
      uv=VALUES(uv),
      unlocks=VALUES(unlocks),
      downloads=VALUES(downloads),
      ad_issued=VALUES(ad_issued),
      ad_rewarded=VALUES(ad_rewarded),
      members_paid=VALUES(members_paid),
      revenue_cent=VALUES(revenue_cent);
  `);
  console.log('metrics_daily upsert ok');
}

(async function main(){
  await run();
  process.exit(0);
})();
