import { Router } from 'express';
import { adminAuth } from '../middleware/admin';
import { pool } from '../utils/db';

const r = Router();
r.use(adminAuth);

r.get('/metrics/daily', async (req, res) => {
  const { from, to } = req.query as any;
  const [rows]: any = await pool.query(
    `SELECT *, 
      ROUND(CASE WHEN ad_issued>0 THEN ad_rewarded*100.0/ad_issued ELSE 0 END,2) AS ad_finish_rate,
      ROUND(CASE WHEN uv>0 THEN unlocks*100.0/uv ELSE 0 END,2) AS unlock_rate,
      ROUND(CASE WHEN unlocks>0 THEN downloads*100.0/unlocks ELSE 0 END,2) AS dl_per_unlock
     FROM metrics_daily
     WHERE day BETWEEN ? AND ?
     ORDER BY day ASC`, [from, to]
  );
  res.json(rows);
});

export default r;
