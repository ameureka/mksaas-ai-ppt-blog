import { pool } from '../utils/db';
import crypto from 'crypto';
import { Wechatpay } from 'wechatpay-node-v3';

const mchid = process.env.WECHAT_MCH_ID!;
const serial = process.env.WECHAT_MCH_CERT_SERIAL!;
const privateKey = (process.env.WECHAT_PRIVATE_KEY_PEM || '').replace(/\\n/g,'\n');
const appid = process.env.WX_APPID!;
const APIV3_KEY = process.env.WECHAT_APIV3_KEY!;
const PLATFORM_CERT_PEM = (process.env.WECHAT_PLATFORM_CERT_PEM || '').replace(/\\n/g,'\n');

const pay = (mchid && serial && privateKey) ? new Wechatpay({ mchid, serial, privateKey, certs: {} }) : null;

export async function createPay(uid: number, openid: string, sku: string, assetId?: number) {
  const [p]: any = await pool.query(`SELECT * FROM products WHERE sku=? AND status='online'`, [sku]);
  if (!p.length) throw new Error('SKU_OFFLINE');
  const prod = p[0];

  const [ins]: any = await pool.query(
    `INSERT INTO orders(uid,type,amount_cent,sku,status) VALUES(?, ?, ?, ?, 'pending')`,
    [uid, prod.type, prod.price_cent, sku]
  );
  const orderId = ins.insertId;

  if (prod.type === 'oneoff' && assetId) {
    await pool.query(`UPDATE orders SET pay_txn_id=? WHERE order_id=?`, [String(assetId), orderId]);
  }

  // 无微信商户配置时，返回模拟参数用于联调
  if (!pay) {
    const timeStamp = String(Math.floor(Date.now()/1000));
    const nonceStr = crypto.randomBytes(16).toString('hex');
    const pkg = `prepay_id=mock_${orderId}`;
    const signType = 'RSA';
    const paySign = 'mock_sign';
    return { orderId, timeStamp, nonceStr, package: pkg, signType, paySign };
  }

  const description = prod.name;
  const notify_url = process.env.PAY_NOTIFY_URL!;
  const total = prod.price_cent;

  const res = await (pay as any).transactions_jsapi({
    appid,
    mchid,
    description,
    out_trade_no: String(orderId),
    notify_url,
    amount: { total, currency: 'CNY' },
    payer: { openid }
  });
  const prepay_id = res['prepay_id'];

  const timeStamp = String(Math.floor(Date.now() / 1000));
  const nonceStr = crypto.randomBytes(16).toString('hex');
  const pkg = `prepay_id=${prepay_id}`;
  const signType = 'RSA';
  const message = `${appid}\n${timeStamp}\n${nonceStr}\n${pkg}\n`;
  const sign = crypto.createSign('RSA-SHA256').update(message).sign(privateKey,'base64');

  return { orderId, timeStamp, nonceStr, package: pkg, signType, paySign: sign };
}

function verifySignature(headers: any, bodyRaw: string) {
  const ts = headers['wechatpay-timestamp'] || headers['Wechatpay-Timestamp'];
  const nonce = headers['wechatpay-nonce'] || headers['Wechatpay-Nonce'];
  const sig = headers['wechatpay-signature'] || headers['Wechatpay-Signature'];
  const serial = headers['wechatpay-serial'] || headers['Wechatpay-Serial'];
  if (!ts || !nonce || !sig || !serial) throw new Error('BAD_NOTIFY_HEADER');
  const message = `${ts}\n${nonce}\n${bodyRaw}\n`;
  const verifier = crypto.createVerify('RSA-SHA256');
  verifier.update(message);
  verifier.end();
  const ok = verifier.verify(PLATFORM_CERT_PEM, Buffer.from(sig, 'base64'));
  if (!ok) throw new Error('SIGN_VERIFY_FAIL');
}

export async function handlePayNotify(headers: any, body: any, rawBody?: string) {
  verifySignature(headers, rawBody || JSON.stringify(body));
  const cipher = body.resource;
  const plain = Wechatpay.decipher_gcm(APIV3_KEY, cipher.associated_data, cipher.nonce, cipher.ciphertext);
  const notify = JSON.parse(plain);

  const out_trade_no = Number(notify.out_trade_no);
  const transaction_id = notify.transaction_id;
  const trade_state = notify.trade_state;
  if (trade_state !== 'SUCCESS') return;

  const [ord]: any = await pool.query(
    `SELECT status, type, pay_txn_id, uid, amount_cent FROM orders WHERE order_id=? LIMIT 1`, [out_trade_no]);
  const order = ord[0];
  if (!order || order.status === 'paid') return;

  await pool.query(`UPDATE orders SET status='paid', pay_txn_id=? WHERE order_id=?`, [transaction_id, out_trade_no]);
  await pool.query(`INSERT INTO pay_logs(order_id, raw_json) VALUES(?, ?)`, [out_trade_no, JSON.stringify(body)]);

  if (order.type === 'oneoff') {
    const assetId = Number(order.pay_txn_id) || 0;
    if (assetId) {
      await pool.query(
        `INSERT INTO unlocks(uid, asset_id, method, expires_at)
           VALUES(?, ?, 'pay', DATE_ADD(NOW(), INTERVAL 365 DAY))
         ON DUPLICATE KEY UPDATE expires_at=GREATEST(expires_at, DATE_ADD(NOW(), INTERVAL 365 DAY))`,
        [order.uid, assetId]
      );
    }
  } else if (order.type === 'member') {
    await pool.query(
      `UPDATE users SET 
          membership_type='monthly',
          membership_expire_at = CASE 
             WHEN membership_expire_at IS NULL OR membership_expire_at < NOW()
               THEN DATE_ADD(NOW(), INTERVAL 30 DAY)
             ELSE DATE_ADD(membership_expire_at, INTERVAL 30 DAY)
          END
       WHERE uid=?`, [order.uid]);
  }

  await pool.query(
    `INSERT INTO metrics_daily(day, revenue_cent, members_paid)
       VALUES(CURDATE(), ?, ?)
     ON DUPLICATE KEY UPDATE 
       revenue_cent = revenue_cent + VALUES(revenue_cent),
       members_paid = members_paid + VALUES(members_paid)`,
    [order.amount_cent, order.type === 'member' ? 1 : 0]
  );
}
