import { Router } from 'express';
import { pool } from '../utils/db';
import { auth } from '../middleware/auth';

const r = Router();

r.get('/me', auth, async (req, res, next) => {
  try {
    const uid = (req as any).user.uid;
    const [[u]]: any = await pool.query(
      `SELECT uid, credits, membership_type, membership_expire_at
         FROM users WHERE uid=? LIMIT 1`, [uid]);
    const [recent]: any = await pool.query(
      `SELECT u.asset_id, a.title, a.cover, u.method, u.created_at
         FROM unlocks u 
         JOIN assets a ON a.asset_id=u.asset_id
        WHERE u.uid=?
        ORDER BY u.created_at DESC
        LIMIT 20`, [uid]);
    res.json({
      uid: u?.uid, credits: u?.credits || 0,
      membership_type: u?.membership_type || 'none',
      membership_expire_at: u?.membership_expire_at,
      recent_unlocks: recent || []
    });
  } catch (e) { next(e); }
});

export default r;
