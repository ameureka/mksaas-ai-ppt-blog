import { Router } from 'express';
import { adminAuth } from '../middleware/admin';
import { pool } from '../utils/db';

const r = Router();
r.use(adminAuth);

/* Assets list/create/update/delete */
r.get('/admin/assets', async (req, res) => {
  const { q='', status, channel_id, page=1, ps=20 } = req.query as any;
  const off = (Number(page)-1)*Number(ps);
  const [rows]: any = await pool.query(
    `SELECT a.*, c.name AS channel
       FROM assets a LEFT JOIN channels c ON a.channel_id=c.channel_id
      WHERE (?='' OR a.title LIKE CONCAT('%',?,'%'))
        AND (? IS NULL OR a.status=?)
        AND (? IS NULL OR a.channel_id=?)
      ORDER BY a.updated_at DESC
      LIMIT ?,?`,
    [q,q,status,status,channel_id,channel_id,off,Number(ps)]
  );
  res.json(rows);
});

r.post('/admin/assets', async (req, res) => {
  const { title, cover, file_key, channel_id, tags=[] } = req.body;
  const [ins]: any = await pool.query(
    `INSERT INTO assets(title,cover,file_key,channel_id,status) VALUES(?,?,?,?, 'online')`,
    [title,cover,file_key,channel_id]
  );
  const id = ins.insertId;
  for (const t of (tags||[])) {
    await pool.query(`INSERT IGNORE INTO tags(name) VALUES(?)`, [t]);
    const [tg]: any = await pool.query(`SELECT tag_id FROM tags WHERE name=?`, [t]);
    await pool.query(`INSERT IGNORE INTO asset_tags(asset_id, tag_id) VALUES(?,?)`, [id, tg[0].tag_id]);
  }
  res.json({ id });
});

r.patch('/admin/assets/:id', async (req, res) => {
  const id = Number(req.params.id);
  const { title, status, channel_id, tags } = req.body;
  await pool.query(
    `UPDATE assets SET 
       title=COALESCE(?,title),
       status=COALESCE(?,status),
       channel_id=COALESCE(?,channel_id),
       updated_at=NOW()
     WHERE asset_id=?`,
    [title, status, channel_id, id]
  );
  if (Array.isArray(tags)) {
    await pool.query(`DELETE FROM asset_tags WHERE asset_id=?`, [id]);
    for (const t of tags) {
      await pool.query(`INSERT IGNORE INTO tags(name) VALUES(?)`, [t]);
      const [tg]: any = await pool.query(`SELECT tag_id FROM tags WHERE name=?`, [t]);
      await pool.query(`INSERT IGNORE INTO asset_tags(asset_id, tag_id) VALUES(?,?)`, [id, tg[0].tag_id]);
    }
  }
  res.json({ ok: true });
});

r.delete('/admin/assets/:id', async (req, res) => {
  const id = Number(req.params.id);
  await pool.query(`UPDATE assets SET status='offline' WHERE asset_id=?`, [id]);
  res.json({ ok: true });
});

/* channels */
r.get('/admin/channels', async (_req, res) => {
  const [rows]: any = await pool.query(`SELECT * FROM channels ORDER BY sort_weight DESC, channel_id ASC`);
  res.json(rows);
});
r.post('/admin/channels', async (req, res) => {
  const { name, sort_weight=0 } = req.body || {};
  const [ins]: any = await pool.query(`INSERT INTO channels(name, sort_weight) VALUES(?,?)`, [name, sort_weight]);
  res.json({ channel_id: ins.insertId });
});
r.patch('/admin/channels/:id', async (req, res) => {
  const id = Number(req.params.id);
  const { name, sort_weight, status } = req.body || {};
  await pool.query(`UPDATE channels SET name=COALESCE(?,name), sort_weight=COALESCE(?,sort_weight), status=COALESCE(?,status) WHERE channel_id=?`,
    [name, sort_weight, status, id]);
  res.json({ ok: true });
});
r.delete('/admin/channels/:id', async (req, res) => {
  const id = Number(req.params.id);
  await pool.query(`DELETE FROM channels WHERE channel_id=?`, [id]);
  res.json({ ok: true });
});

/* tags */
r.get('/admin/tags', async (_req, res) => {
  const [rows]: any = await pool.query(`SELECT * FROM tags ORDER BY tag_id ASC`);
  res.json(rows);
});
r.post('/admin/tags', async (req, res) => {
  const { name } = req.body || {};
  const [ins]: any = await pool.query(`INSERT INTO tags(name) VALUES(?)`, [name]);
  res.json({ tag_id: ins.insertId });
});
r.patch('/admin/tags/:id', async (req, res) => {
  const id = Number(req.params.id);
  const { name, status } = req.body || {};
  await pool.query(`UPDATE tags SET name=COALESCE(?,name), status=COALESCE(?,status) WHERE tag_id=?`, [name, status, id]);
  res.json({ ok: true });
});
r.delete('/admin/tags/:id', async (req, res) => {
  const id = Number(req.params.id);
  await pool.query(`DELETE FROM tags WHERE tag_id=?`, [id]);
  res.json({ ok: true });
});

/* search weights */
r.post('/admin/search-weights', async (req, res) => {
  const { scope, ref_id, weight } = req.body;
  await pool.query(
    `INSERT INTO search_weights(scope, ref_id, weight) VALUES(?,?,?)
     ON DUPLICATE KEY UPDATE weight=VALUES(weight)`,
    [scope, ref_id, weight]
  );
  res.json({ ok: true });
});

export default r;
