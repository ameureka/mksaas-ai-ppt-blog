import { Router } from 'express';
import { auth } from '../middleware/auth';
import { createPay, handlePayNotify } from '../services/pay';
import { pool } from '../utils/db';
import bodyParser from 'body-parser';

const r = Router();

/** 创建支付：小程序端请求 */
r.post('/pay/create', auth, async (req, res, next) => {
  try {
    const uid = (req as any).user.uid;
    const { sku, asset_id } = req.body;
    const [u]: any = await pool.query(`SELECT openid FROM users WHERE uid=?`, [uid]);
    const openid = (u[0]?.openid) || 'test_openid';
    const data = await createPay(uid, openid, sku, Number(asset_id));
    res.json(data);
  } catch (e) { next(e); }
});

/** 微信支付回调：需要原始 body 验签 */
r.post('/pay/notify',
  bodyParser.json({ verify: (req: any, _res, buf) => { req.rawBody = buf.toString(); } }),
  async (req: any, res) => {
    try {
      await handlePayNotify(req.headers, req.body, req.rawBody);
      res.status(200).json({ code: 'SUCCESS' });
    } catch (e) {
      console.error('pay notify error', e);
      res.status(500).json({ code: 'FAIL', message: 'notify error' });
    }
  }
);

export default r;
