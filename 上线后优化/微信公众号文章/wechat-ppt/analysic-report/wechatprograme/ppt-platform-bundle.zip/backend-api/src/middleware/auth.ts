import jwt from 'jsonwebtoken';
import { Request, Response, NextFunction } from 'express';

export function auth(req: Request & { user?: any }, res: Response, next: NextFunction) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : '';
  if (!token) return res.status(401).json({ error: 'NO_TOKEN' });
  try {
    const payload = jwt.verify(token, process.env.USER_JWT_SECRET || 'user_secret');
    req.user = payload;
    next();
  } catch {
    res.status(401).json({ error: 'BAD_TOKEN' });
  }
}
