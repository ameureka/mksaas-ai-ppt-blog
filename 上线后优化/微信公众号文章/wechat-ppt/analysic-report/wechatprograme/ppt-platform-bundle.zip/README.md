# PPT 模板平台一体化交付包

本压缩包包含三部分：
1) **backend-api/**（Node 18 + Express + MySQL）— 核心服务端
2) **miniapp-prototype/**（微信小程序前端原型）
3) **react-admin-panel/**（React Admin 管理台）

## 启动总览
- 数据库：导入 `backend-api/schema.sql`
- 服务端：`cd backend-api && cp .env.example .env && npm i && npm run dev`
- 管理台：`cd react-admin-panel && npm i && echo 'VITE_API_BASE=http://localhost:8080' > .env && npm run dev`
- 小程序：用微信开发者工具导入 `miniapp-prototype`，修改 `config/config.js` 的 `baseURL` 为你的后端地址

## 关键链路
小程序详情页 → 解锁（激励广告）或支付（微信 JSAPI） → `/ad/confirm` 或 `/pay/notify` → 生成短时效下载链接 `/download/link` → 邮件发送 `/email/send` → 日志沉淀 `/metrics/daily`。

更多说明见各子目录 README。
